import processing.core.*; 
import processing.data.*; 
import processing.event.*; 
import processing.opengl.*; 

import java.util.HashMap; 
import java.util.ArrayList; 
import java.io.File; 
import java.io.BufferedReader; 
import java.io.PrintWriter; 
import java.io.InputStream; 
import java.io.OutputStream; 
import java.io.IOException; 

public class sketch_11_Etch_A_Sketch extends PApplet {

int x, y;

public void setup() {
  size(500, 500);
  frameRate(10);
  background(150);
  //set start coord
  x=width/2;
  y=height/2;
}

//method to draw right line
public void moveRight(int rep) {
  for (int i=0; i<rep*10; i++) {
    point (x+i, y);
  }
  x=x+(10*rep);
}

public void moveLeft(int rep) {
  for (int i=0; i<rep*10; i++) {
    point (x-i, y);
  }
  x=x-(10*rep);
}

public void moveUp(int rep) {
  for (int i=0; i<rep*10; i++) {
    point (x, y-i);
  }
  y=y-(10*rep);
}

public void moveDown(int rep) {
  for (int i=0; i<rep*10; i++) {
    point (x, y+i);
  }
  y=y+(10*rep);
}

public void moveDownRight(int rep) {
  for (int i=0; i<rep*10; i++) {
    point (x+(i/2), y+i);
  }
  y=y+(10*rep);
  x=x+(10*rep)/2;
}
public void moveUpLeft(int rep) {
  for (int i=0; i<rep*10; i++) {
    point (x-(i/2), y-i);
  }
  y=y-(10*rep);
  x=x-(10*rep)/2;
}
public void moveDownLeft(int rep) {
  for (int i=0; i<rep*10; i++) {
    point (x-(i/2), y+i);
  }
  y=y+(10*rep);
  x=x-(10*rep)/2;
}
public void moveUpRight(int rep) {
  for (int i=0; i<rep*10; i++) {
    point (x+(i/2), y-i);
  }
  y=y-(10*rep);
  x=x+(10*rep)/2;
}

public void draw() {
  if (keyPressed) {
    if (key == 'a' || key == '4') {
      moveLeft(1);
    } else if (key == 'd' || key == '6') {
      moveRight(1);
    } else if (key == 's' || key == '5') {
      moveDown(1);
    } else if (key == 'w' || key == '8') {
      moveUp(1);
    } else if (key == 'e' || key == '9') {
      moveUpRight(1);
    } else if (key == 'q' || key == '7') {
      moveUpLeft(1);
    } else if (key == 'c' || key == '3') {
      moveDownRight(1);
    } else if (key == 'z' || key == '1') {
      moveDownLeft(1);
    } else if (key == 'b' || key == '2') {
      background(150);
    }
  }
}
public void mouseClicked() {
  saveFrame("line-#####.png");
}
  static public void main(String[] passedArgs) {
    String[] appletArgs = new String[] { "--full-screen", "--bgcolor=#666666", "--hide-stop", "sketch_11_Etch_A_Sketch" };
    if (passedArgs != null) {
      PApplet.main(concat(appletArgs, passedArgs));
    } else {
      PApplet.main(appletArgs);
    }
  }
}
